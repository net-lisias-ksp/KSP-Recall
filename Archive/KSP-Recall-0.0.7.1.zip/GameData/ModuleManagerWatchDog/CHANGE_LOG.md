# Module Manager Watch Dog :: Change Log

* 2020-0612: 0.0.2.0 (LisiasT) for KSP >= 1.4
	+ Minor fixes and adjustments
* 2020-0612: 0.0.1.0 (LisiasT) for KSP >= 1.4
	+ Initial public release
	+ Works on KSP >= 1.4, but it's only needed on KSP >= 1.8 
