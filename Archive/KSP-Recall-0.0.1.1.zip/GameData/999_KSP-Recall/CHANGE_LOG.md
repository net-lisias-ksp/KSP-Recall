# KSP-Recall :: Change Log

* 2020-0301: 0.0.1.1 (LisiasT) for KSP >= 1.4.1 PRE-RELEASE
	+ Initial Release for Evaluation made right this time.
* 2020-0301: 0.0.1.0 (LisiasT) for KSP >= 1.4.1 PRE-RELEASE
	+ Initial Release for Evaluation
	+ Currently compatible only with TweakScale
